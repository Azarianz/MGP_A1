package com.sdm.mgp2022;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.SurfaceView;

import androidx.core.content.ContextCompat;

public class Player implements EntityBase
{
    private double positionX;
    private double positionY;
    private double radius;
    private Paint paint;

    public Player(Context context, double positionX, double positionY, double radius) {
        this.positionX = positionX;
        this.positionY = positionY;
        this.radius = radius;

        paint = new Paint();
        int color = ContextCompat.getColor(context, R.color.player);
        paint.setColor(color);

        Player result = new Player();
        EntityManager.Instance.AddEntity(result, ENTITY_TYPE.ENT_PLAYER);
    }

    public boolean IsDone() {
        return false;
    }

    public void SetIsDone(boolean _isDone) {

    }

    public void Init(SurfaceView _view) {

    }

    public void Update(float _dt) {

    }

    public void Render(Canvas _canvas) {
        _canvas.drawCircle((float)positionX, (float)positionY, (float)radius, paint );
    }

    public boolean IsInit() {
        return false;
    }

    public int GetRenderLayer() {
        return LayerConstants.GAMEOBJECTS_LAYER;
    }

    public void SetRenderLayer(int _newLayer) { return; }

    public ENTITY_TYPE GetEntityType() { return ENTITY_TYPE.ENT_PLAYER; }

    public static Player Create() {

        return result;
    }
}
